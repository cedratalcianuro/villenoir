function selectColor(card, color, imageUrl) {
 
    const productImage = card.querySelector('img');
    productImage.src = imageUrl;
 
   
    const priceElement = card.querySelector('.product-price');
 
   
    const price = priceElement.getAttribute(`data-price-${color}`);
    priceElement.textContent = price;
 
    const colorButtons = card.querySelectorAll('.color-btn');
    colorButtons.forEach(function(button) {
        button.classList.remove('active');
    });
 
    const selectedButton = Array.from(colorButtons).find(button => button.dataset.color === color);
    if (selectedButton) {
        selectedButton.classList.add('active');
    }
}
 
 
function addToCart(event) {
    const card = event.target.closest('.product-card');
    const productName = card.querySelector('.product-title').textContent;
    const productPrice = card.querySelector('.product-price').textContent;
 
    const cartItems = document.getElementById('cartItems');
    const totalPrice = document.getElementById('totalPrice');
 
    cartItems.innerHTML += `<p>${productName} - ${productPrice}</p>`;
 
    let total = parseFloat(totalPrice.textContent.replace('€', '')) || 0;
    total += parseFloat(productPrice.replace('€', ''));
    totalPrice.textContent = `€${total.toFixed(2)}`;
}
 
 
document.querySelectorAll('.color-btn').forEach(button => {
    button.addEventListener('click', function() {
        const card = button.closest('.product-card');
        const color = button.dataset.color;
        const imageUrl = button.dataset.image;
        selectColor(card, color, imageUrl);
    });
});
 
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', addToCart);
});
 
 
 
 
 
 
 
function selectVolume(card, volume, price) {
 
    const priceElement = card.querySelector('.product-price');
    priceElement.textContent = price;
 
 
    const volumeButtons = card.querySelectorAll('.volume-btn');
    volumeButtons.forEach(function(button) {
        button.classList.remove('active');
    });
 
    const selectedButton = Array.from(volumeButtons).find(button => button.dataset.volume == volume);
    if (selectedButton) {
        selectedButton.classList.add('active');
    }
}
 
function addToCart(event) {
    const card = event.target.closest('.product-card');
    const productName = card.querySelector('.product-title').textContent;
    const productPrice = card.querySelector('.product-price').textContent;
 
    const cartItems = document.getElementById('cartItems');
    const totalPrice = document.getElementById('totalPrice');
 
    cartItems.innerHTML += `<p>${productName} - ${productPrice}</p>`;
 
    let total = parseFloat(totalPrice.textContent.replace('€', '')) || 0;
    total += parseFloat(productPrice.replace('€', ''));
    totalPrice.textContent = `€${total.toFixed(2)}`;
}
 
document.querySelectorAll('.volume-btn').forEach(button => {
    button.addEventListener('click', function() {
        const card = button.closest('.product-card');
        const volume = button.dataset.volume;
        const price = button.dataset.price;
        selectVolume(card, volume, price);
    });
});
 
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', addToCart);
});
 
 
 
 
 
 
function addToCart(event) {
    const card = event.target.closest('.product-card');
    const productName = card.querySelector('.product-title').textContent;
    const productPrice = card.querySelector('.product-price').textContent;
    const productId = card.id;
 
    const cartItems = document.getElementById('cartItems');
    const totalPrice = document.getElementById('totalPrice');
 
 
   
    const cartItem = document.createElement('div');
    cartItem.id = `cart-item-${productId}`;
    cartItem.innerHTML = `
        <input type="checkbox" class="cart-item-checkbox" data-id="${productId}" onchange="updateTotal()">
        <span>${productName} - ${productPrice}</span>
        <button class="remove-item" onclick="removeFromCart('${productId}')">X</button>
    `;
    cartItems.appendChild(cartItem);
 
   
    updateTotal();
}
 
 
function removeFromCart(productId) {
    const cartItem = document.getElementById(`cart-item-${productId}`);
    if (cartItem) {
        cartItem.remove();
    }
 
    updateTotal();
}
 
 
function updateTotal() {
    let total = 0;
    const checkboxes = document.querySelectorAll('.cart-item-checkbox');
    checkboxes.forEach(function(checkbox) {
        if (checkbox.checked) {
            const cartItem = checkbox.closest('div');
            const priceText = cartItem.querySelector('span').textContent.split(' - ')[1];
            total += parseFloat(priceText.replace('€', ''));
        }
    });
    const totalPrice = document.getElementById('totalPrice');
    totalPrice.textContent = `€${total.toFixed(2)}`;
}
function placeOrder() {
    const cartItems = document.getElementById('cartItems');
    const totalPrice = document.getElementById('totalPrice');
 
    if (cartItems.innerHTML === 'Il carrello è vuoto') {
        alert('Il carrello è vuoto. Aggiungi prodotti al carrello!');
        return;
    }
 
    alert(`Ordine effettuato! Totale: ${totalPrice.textContent}`);
 
    cartItems.innerHTML = 'Il carrello è vuoto';
    totalPrice.textContent = '€0';
}
 
 
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', addToCart);
});
 
 
 
 
 
 
 
    function updateCart() {
        let cartItemsContainer = document.getElementById("cartItems");
        cartItemsContainer.innerHTML = "";
 
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = "Il carrello è vuoto";
        } else {
            cart.forEach((item, index) => {
                cartItemsContainer.innerHTML += `
                    <div class="cart-item">
                        <input type="checkbox" onchange="calculateTotal()" class="cart-checkbox" data-price="${parseFloat(item.price.replace('€', ''))}">
                        ${item.name} - ${item.volume} ml - ${item.price}
                    </div>
                `;
            });
        }
 
        calculateTotal();
    }
 
    function calculateTotal() {
        let checkboxes = document.querySelectorAll(".cart-checkbox");
        let total = 0;
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                total += parseFloat(checkbox.getAttribute("data-price"));
            }
        });
 
        document.getElementById("totalPrice").innerText = `€${total}`;
    }
 
    function toggleCart() {
        let cartSidebar = document.getElementById("cartSidebar");
        cartSidebar.classList.toggle("open");
    }
 
    function placeOrder() {
        if (cart.length === 0) {
            alert("Il carrello è vuoto. Aggiungi prodotti prima di ordinare.");
            return;
        }
 
        alert("Il tuo ordine è stato effettuato con successo!");
    }
 
 
    function toggleMenu() {
        document.getElementById("menuSidebar").classList.toggle("open");
        document.getElementById("overlay").classList.toggle("show");
    }
 
    function toggleCart() {
        let cart = document.getElementById("cartSidebar");
        if (cart.classList.contains("open")) {
            cart.style.right = "-100%";
            cart.classList.remove("open");
        } else {
            cart.style.right = "0";
            cart.classList.add("open");
        }
    }
 
    function placeOrder() {
        alert("Il tuo ordine è stato effettuato con successo!");
    }
 
 
//slider
    let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const totalSlides = slides.length;
 
 
function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    const slider = document.querySelector('.slider');
    slider.style.transform = `translateX(-${currentSlide * 100}vw)`;
}
 
 
setInterval(nextSlide, 5000);
 
//slider2
 
let slider1Index = 0;
 
function slideSlider1(direction) {
  const track = document.querySelector('.slider1-track');
  const totalItems = 8;
  const visibleItems = 4;
  const maxIndex = totalItems - visibleItems;
 
  slider1Index += direction;
 
  if (slider1Index > maxIndex) {
    slider1Index = 0;
  } else if (slider1Index < 0) {
    slider1Index = maxIndex;
  }
 
  const shift = -(100 / visibleItems) * slider1Index;
  track.style.transform = `translateX(${shift}%)`;
}
 
 
 
 
let slider2Index = 0;
 
function slideSlider2(direction) {
  const track = document.querySelector('.slider2-track');
  const totalItems = 8;
  const visibleItems = 4;
  const maxIndex = totalItems - visibleItems;
 
  slider2Index += direction;
 
  if (slider2Index > maxIndex) {
    slider2Index = 0;
  } else if (slider2Index < 0) {
    slider2Index = maxIndex;
  }
 
  const shift = -(100 / visibleItems) * slider2Index;
  track.style.transform = `translateX(${shift}%)`;
}
 
 
 
 
 
 
let slider3Index = 0;
 
function slideSlider3(direction) {
  const track = document.querySelector('.slider3-track');
  const totalItems = 8;
  const visibleItems = 4;
  const maxIndex = totalItems - visibleItems;
 
  slider3Index += direction;
 
  if (slider3Index > maxIndex) {
    slider3Index = 0;
  } else if (slider3Index < 0) {
    slider3Index = maxIndex;
  }
 
  const shift = -(100 / visibleItems) * slider3Index;
  track.style.transform = `translateX(${shift}%)`;
}